#include <stdio.h>
#include<stdlib.h> 
#include"StudentAction.h" 

#include"sys_menu.h"
#include"fromLogin.h"
#include"StudentBLL.h"
#include"commonpositiontool.h"
#include<windows.h>
#include"Student.h"
#include"StudentADT.h"
#include"StudentFile.h"

void main_menu_choose( struct studentNode* list ,int menu_number){
	system("cls");
	switch(menu_number){
		case 0:
			quit();
			break;
		case 1:   //ѧ����Ϣ������ 
			addStudent(list);
			break;
		case 2:
			sortStudent();  
			break;
		case 3:
			queryStudent();
			break;
		case 4:
			queryStudentClassification(); 
			break;
		case 5:
			deleteStudent();
			break;
		case 6:	
			updateStudentInfo();
			break;
		default:
			showMessage();  
			break;				 			
	}


	system("pause");
}


