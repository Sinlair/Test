#include <stdio.h>
#include<stdlib.h> 
#include"sys_menu.h"
#include"StudentAction.h"
#include"fromLogin.h"
#include"StudentBLL.h"
#include"commonpositiontool.h"
#include<windows.h>
#include"Student.h"
#include"StudentADT.h"
#include"StudentAction.h" 
void gotoxy( int xpos, int ypos){  //��궨λ���� 
	COORD scrn;
	HANDLE hOuput = GetStdHandle(STD_OUTPUT_HANDLE); //��ȡ��ǰ������� 
	scrn.X = xpos;
	scrn.Y = ypos; 
	SetConsoleCursorPosition(hOuput, scrn);	

}
