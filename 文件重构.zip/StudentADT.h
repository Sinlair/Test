
struct studentNode* createList();
void insertNodeByHead(struct studentNode* listHeadNode, struct student data);
struct studentNode* create(struct student data);
