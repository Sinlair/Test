void main_menu_choose(struct studentNode* list, int menu_number);
