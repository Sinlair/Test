#include <stdio.h>
#include<stdlib.h> 
#include"sys_menu.h"
#include"StudentAction.h"
#include"fromLogin.h"
#include"StudentBLL.h"
#include"commonpositiontool.h"
#include<windows.h>
#include"Student.h"
#include"StudentADT.h"
#include"StudentAction.h" 

void welcome_menu(){
	printf("\n\n\n");
	printf("****************************************************\n\n");
	printf("            *��ӭ��������Ϣ����ϵͳ*           \n\n");
	printf("     *       SWPU����С��Ϊ������           *\n\n");
	printf("   *****                                 ****** \n ");
	printf("  *                                          * \n ");
	printf("  *                                          * \n ");
	printf("  *                                          * \n ");
	printf("  *                                          * \n ");
	printf("  *                                          * \n ");
	printf("  *****                                 ****** \n ");	
	printf("\t         \n");
	printf("\n\n\n\n\n\n"); 
    system("pause");//��ͣ	
	system("cls");//���� 	
}
void main_menu(){
	printf("\t\t    *********ѧ������ϵͳ************\n");
	printf("\t\t |....................................|  \n");
	printf("\t\t |��ѡ�������ţ�0 - 6��|\n");
	printf("\t\t |....................................|  \n");	
	printf("\t\t | 1---ѧ����Ϣ¼�� |\n\n");
	printf("\t\t | 2---ѧ����Ϣ���� |\n\n");
	printf("\t\t | 3---ѧ����Ϣ��ѯ |\n\n");
	printf("\t\t | 4---ѧ�������ѯ |\n\n");
	printf("\t\t | 5---ѧ����Ϣɾ�� |\n\n");
	printf("\t\t | 6---ѧ����Ϣ�޸� |\n\n");
	printf("\t\t | 0---�˳� |\n\n");
	printf("\t\t |....................................|  \n\n");
	printf("\t\t    ********************************\n\n\n\n");	
	
}

void head_menu(){
	printf("     *       SWPU����С��Ϊ������           *\n\n");
	printf("   *****                                 ****** \n ");
	printf("  *                                          * \n ");
	printf("  *                                          * \n ");
	printf("  *                                          * \n ");
	printf("  *                                          * \n ");
	printf("  *                                          * \n ");
	printf("  *****                                 ****** \n ");	

	system("pause");//��ͣ	
	gotoxy(3, 3);
}
