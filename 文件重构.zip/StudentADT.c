#include"Student.h"
#include"StudentADT.h"
#include<stdlib.h> 
#include"StudentAction.h" 
struct studentNode* createList(){
	struct studentNode* listHeadNode = (struct studentNode*)malloc(sizeof(struct studentNode));
	listHeadNode->next = NULL;
	return listHeadNode;
}

struct studentNode* createNode(struct student data){
	struct studentNode* newNode = (struct studentNode*)malloc(sizeof(struct studentNode));
	newNode->data = data;
	newNode->next = NULL;
	return newNode;
}

void insertNodeByHead(struct studentNode* listHeadNode, struct student data){
	struct studentNode* newNode = createNode(data);
	newNode->next = listHeadNode->next;
	listHeadNode->next = newNode;
}
