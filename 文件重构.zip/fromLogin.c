#include <stdio.h>
#include<stdlib.h> 
#include"sys_menu.h"
#include"StudentAction.h"
#include"fromLogin.h"
#include"StudentBLL.h"
#include"commonpositiontool.h"
#include<windows.h>
#include"Student.h"
#include"StudentADT.h"
#include"StudentAction.h" 

void login_menu(){
	head_menu();
}
